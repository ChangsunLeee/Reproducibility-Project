import matplotlib.pyplot as plt
import numpy as np
import pyaudio
import time
import cv2


class AudioVis:
    def __init__(self, form, channels, rate, buffer):
        self.rate = rate
        self.buffer = bufferi

        self.p = pyaudio.PyAudio()
        self.stream = self.p.open(
            format=form,
            channels=channels,
            rate=rate,
            input=True,
            frames_per_buffer=buffer)
        
        print(self.stream.__class__.__name__)

    def get_data(self):
        input_data = self.stream.read(self.buffer)
        data = np.frombuffer(input_data, np.float32)
        return data

    def draw_graph(self, dat):
        fig = plt.figure()
        plt.specgram(dat, Fs=self.rate)
        plt.ylabel('Frequency [Hz]')
        plt.xlabel('Time [sec]')
        fig.canvas.draw()

        img = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
        img  = img.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        img = cv2.cvtColor(img,cv2.COLOR_RGB2BGR)
        plt.close(fig)

        self.stream.stop_stream()
        self.stream.close()

        cv2.imshow("img", img)
        if cv2.waitKey(0) & 0xFF == ord('q'):
            return 0


if __name__ == '__main__':
    FORMAT = pyaudio.paFloat32
    CHANNELS = 1
    RATE = 6000
    SAMPLE_TIME = 5  # sec
    BUFFER = RATE * SAMPLE_TIME
    
    vis = AudioVis(FORMAT, CHANNELS, RATE, BUFFER)
    timestamp = time.strftime('%Y-%m-%d_%H\'%M\'%S')
    dat = vis.get_data()
    np.savetxt(f'{timestamp}_mic.csv', dat, delimiter=",")
    vis.draw_graph(dat)