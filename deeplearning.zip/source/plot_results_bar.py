import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np

base_folder_path = r'C:\Users\hp\OneDrive\바탕 화면\deeplearning\results\ablation'  #폴더경로

common_names = ['Tmall', 'diginetica', 'Nowplaying', 'RetailRocket']

folder_mapping = {
    'noposition': 'DHCN-P',
    'position': 'DHCN',
    'session embedding': 'DHCN-NA'
}

results = []

for sub_folder in os.listdir(base_folder_path):
    sub_folder_path = os.path.join(base_folder_path, sub_folder)
    if os.path.isdir(sub_folder_path):
        for file_name in os.listdir(sub_folder_path):
            if file_name.endswith('.csv'):
                file_path = os.path.join(sub_folder_path, file_name)

                df = pd.read_csv(file_path)
                if 'Recall@20' in df.columns and 'MRR20' in df.columns:
                    recall20_mean = df['Recall@20'].mean()
                    mrr20_mean = df['MRR20'].mean()

                    for name in common_names:
                        if name in file_name:
                            method = folder_mapping.get(sub_folder, sub_folder)
                            results.append({
                                'File Name': os.path.splitext(file_name)[0],
                                'Dataset': name,
                                'Method': method,
                                'Recall@20 Mean': recall20_mean,
                                'MRR20 Mean': mrr20_mean
                            })
                            break

results_df = pd.DataFrame(results)

results_df.sort_values(by=['Dataset', 'Method'], ascending=[True, True], inplace=True)

print(results_df)

datasets = results_df['Dataset'].unique()
methods = results_df['Method'].unique()
n_datasets = len(datasets)
width = 0.2
x_labels = ['Prec@20', 'MRR@20']

fig, axes = plt.subplots(nrows=1, ncols=n_datasets, figsize=(20, 5), sharey=True)

for i, dataset in enumerate(datasets):
    ax = axes[i]
    dataset_df = results_df[results_df['Dataset'] == dataset]
    
    x = np.arange(len(x_labels))
    
    for j, method in enumerate(methods):
        method_df = dataset_df[dataset_df['Method'] == method]
        recall_mean = method_df['Recall@20 Mean'].values[0]
        mrr_mean = method_df['MRR20 Mean'].values[0]
        
        ax.bar(x + j * width, [recall_mean, mrr_mean], width, label=method)
    
    ax.set_title(dataset)
    ax.set_xticks(x + width)
    ax.set_xticklabels(x_labels)
    
    if i == 0:
        ax.set_ylabel('Performance %')
    ax.legend() 

plt.tight_layout()
plt.savefig(r'C:\Users\hp\OneDrive\바탕 화면\deeplearning\results\performance_graphs.png')  #저장위치
plt.show()

print("결과가 성공적으로 저장되었습니다.")
